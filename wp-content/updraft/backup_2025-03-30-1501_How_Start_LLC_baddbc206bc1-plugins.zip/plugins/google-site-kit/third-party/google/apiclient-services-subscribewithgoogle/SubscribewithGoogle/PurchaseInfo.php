<?php

/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
namespace Google\Site_Kit_Dependencies\Google\Service\SubscribewithGoogle;

class PurchaseInfo extends \Google\Site_Kit_Dependencies\Google\Model
{
    /**
     * @var string
     */
    public $latestOrderId;
    protected $totalAmountType = \Google\Site_Kit_Dependencies\Google\Service\SubscribewithGoogle\Money::class;
    protected $totalAmountDataType = '';
    /**
     * @param string
     */
    public function setLatestOrderId($latestOrderId)
    {
        $this->latestOrderId = $latestOrderId;
    }
    /**
     * @return string
     */
    public function getLatestOrderId()
    {
        return $this->latestOrderId;
    }
    /**
     * @param Money
     */
    public function setTotalAmount(\Google\Site_Kit_Dependencies\Google\Service\SubscribewithGoogle\Money $totalAmount)
    {
        $this->totalAmount = $totalAmount;
    }
    /**
     * @return Money
     */
    public function getTotalAmount()
    {
        return $this->totalAmount;
    }
}
// Adding a class alias for backwards compatibility with the previous class name.
\class_alias(\Google\Site_Kit_Dependencies\Google\Service\SubscribewithGoogle\PurchaseInfo::class, 'Google\\Site_Kit_Dependencies\\Google_Service_SubscribewithGoogle_PurchaseInfo');
