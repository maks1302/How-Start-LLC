<?php

namespace Google\Site_Kit_Dependencies\GuzzleHttp\Exception;

class TooManyRedirectsException extends \Google\Site_Kit_Dependencies\GuzzleHttp\Exception\RequestException
{
}
